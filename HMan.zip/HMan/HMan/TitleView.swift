//
//  TitleView.swift
//  HMan
//
//  Created by James Steimel on 12/2/16.
//  Copyright © 2016 James Steimel. All rights reserved.
//

import UIKit

class TitleView: UIView {
    
    override func draw(_ rect: CGRect) {
        // Drawing code
        let textLayer = CATextLayer()
        textLayer.frame = bounds
        textLayer.rasterizationScale = UIScreen.main.scale
        textLayer.contentsScale = UIScreen.main.scale
        textLayer.alignmentMode = kCAAlignmentCenter
        textLayer.fontSize = 100.0
        textLayer.font = UIFont(name: "AvenirNextCondensed-Heavy", size: 100.0)
        textLayer.isWrapped = true
        textLayer.truncationMode = kCATruncationEnd
        textLayer.string = "HANG MAN"

        let imageLayer = CALayer()
        imageLayer.bounds = bounds
        imageLayer.position = CGPoint(x: bounds.midX, y: bounds.midY)
        let image = #imageLiteral(resourceName: "gallows")
        imageLayer.contents = image.cgImage
        imageLayer.borderColor = UIColor.black.cgColor
        imageLayer.borderWidth = 2.0
        
        layer.addSublayer(imageLayer)
        layer.mask = textLayer
    }
}
