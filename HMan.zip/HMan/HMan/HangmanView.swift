//
//  HangmanView.swift
//  HMan
//
//  Created by James Steimel on 12/2/16.
//  Copyright © 2016 James Steimel. All rights reserved.
//

import UIKit

enum BodyPart: Int {
    case noose = 0
    case head
    case body
    case leftLeg
    case rightLeg
    case leftArm
    case rightArm
    case leftEye
    case rightEye
    case mouth
    case final
}

class HangmanView: UIView {
    
    private(set) var partLayers = [CAShapeLayer]()
    private var bodyStart: CGPoint = CGPoint.zero
    private var bodyEnd: CGPoint = CGPoint.zero
    private var headMiddle: CGPoint = CGPoint.zero
    private var currentPart: BodyPart?
    
    
    func clear() {
        for i in partLayers {
            i.removeFromSuperlayer()
        }
        partLayers.removeAll()
    }
    
    func add(part: BodyPart){
        
        currentPart = part
        let newPartLayer = CAShapeLayer()
        
        let partPath = path(forPart: part)
        newPartLayer.frame = bounds
        newPartLayer.path = partPath.cgPath
        newPartLayer.strokeColor = UIColor.black.cgColor
        newPartLayer.fillColor = UIColor.clear.cgColor
        
        newPartLayer.lineCap = kCALineCapRound
        newPartLayer.lineWidth = part == .rightEye || part == .leftEye ? 1 : 2
        
        let strokeAnim = CABasicAnimation(keyPath: "strokeEnd")
        strokeAnim.fromValue = 0
        strokeAnim.toValue = 1
        strokeAnim.duration = 1
        layer.addSublayer(newPartLayer)
        newPartLayer.add(strokeAnim, forKey: "path")
        partLayers.append(newPartLayer)
        
    }
    
    func turnRed(){
        
    }
    
    func path(forPart: BodyPart) -> UIBezierPath {
        
        switch forPart {
        case .noose:
            return UIBezierPath()
            
            
        case .head :
            let centerX = CGFloat(bounds.size.width * DrawingConstants.gallowAcrossScale - (DrawingConstants.gallowHeightWidth / 2))
            let centerY = CGFloat(bounds.size.height * DrawingConstants.gallowHeight + DrawingConstants.gallowBaseHeight + DrawingConstants.gallowTipHeight + ScaleConstants.headRadius)
            let center = CGPoint(x: centerX, y: centerY)
            headMiddle = center
            let path = UIBezierPath(arcCenter: center, radius: ScaleConstants.headRadius, startAngle: CGFloat(0), endAngle: CGFloat(2 * M_PI), clockwise: true)
            
            return path
            
        case .body :
            let add = CGFloat(DrawingConstants.gallowBaseHeight + DrawingConstants.gallowTipHeight + 2 * ScaleConstants.headRadius)
            let startPointY = CGFloat(bounds.size.height * DrawingConstants.gallowHeight + add)
            let startPointX = CGFloat(bounds.size.width * DrawingConstants.gallowAcrossScale - (DrawingConstants.gallowHeightWidth / 2))
            let startPoint = CGPoint(x: startPointX, y: startPointY)
            let endPoint = CGPoint(x: startPoint.x, y: startPoint.y + ScaleConstants.bodyLength)
            bodyStart = startPoint
            bodyEnd = endPoint
            let path = UIBezierPath()
            path.move(to: startPoint)
            path.addLine(to: endPoint)
            return path
            
        case .leftLeg :
            let startPoint = CGPoint(x: bodyEnd.x, y: bodyEnd.y)
            let endPoint = CGPoint(x: startPoint.x - ScaleConstants.limbLength, y: startPoint.y + ScaleConstants.limbLength)
            let path = UIBezierPath()
            path.move(to: startPoint)
            path.addLine(to: endPoint)
            return path
            
        case .rightLeg :
            let startPoint = CGPoint(x: bodyEnd.x, y: bodyEnd.y)
            let endPoint = CGPoint(x: startPoint.x + ScaleConstants.limbLength, y: startPoint.y + ScaleConstants.limbLength)
            let path = UIBezierPath()
            path.move(to: startPoint)
            path.addLine(to: endPoint)
            return path
            
        case .leftArm :
            let startPoint = CGPoint(x: bodyStart.x, y: bodyStart.y + ScaleConstants.handHeightScale * ScaleConstants.bodyLength)
            let endPoint = CGPoint(x: startPoint.x - ScaleConstants.limbLength, y: startPoint.y - ScaleConstants.limbLength * ScaleConstants.handHeightScale)
            let path = UIBezierPath()
            path.move(to: startPoint)
            path.addLine(to: endPoint)
            return path
            
        case .rightArm :
            let startPoint = CGPoint(x: bodyStart.x, y: bodyStart.y + ScaleConstants.handHeightScale * ScaleConstants.bodyLength)
            let endPoint = CGPoint(x: startPoint.x + ScaleConstants.limbLength, y: startPoint.y - ScaleConstants.limbLength * ScaleConstants.handHeightScale)
            let path = UIBezierPath()
            path.move(to: startPoint)
            path.addLine(to: endPoint)
            return path
            
        case .leftEye :
            UIColor.black.set()
            let eyeMiddle = CGPoint(x: headMiddle.x - ScaleConstants.eyeOffset, y: headMiddle.y - ScaleConstants.eyeOffset)
            
            let path = UIBezierPath(arcCenter: eyeMiddle, radius: ScaleConstants.eyeRadius, startAngle: 0, endAngle: CGFloat(2 * M_PI), clockwise: true)
            path.lineWidth = CGFloat(1)
            return path
            
        case .rightEye :
            UIColor.black.set()
            let eyeMiddle = CGPoint(x: headMiddle.x + ScaleConstants.eyeOffset, y: headMiddle.y - ScaleConstants.eyeOffset)
            
            let path = UIBezierPath(arcCenter: eyeMiddle, radius: ScaleConstants.eyeRadius, startAngle: 0, endAngle: CGFloat(2 * M_PI), clockwise: true)
            path.lineWidth = CGFloat(1)
            return path
            
        case .mouth:
            UIColor.black.set()
            let mouthMiddle = CGPoint(x: headMiddle.x, y: headMiddle.y + ScaleConstants.mouthOffSet)
            let path = UIBezierPath(arcCenter: mouthMiddle, radius: ScaleConstants.mouthRadius, startAngle: 0, endAngle: CGFloat(2 * M_PI), clockwise: true)
                    path.lineWidth = CGFloat(1)
            return path
        case .final:
            return UIBezierPath()
        }
    }
    
    
    
    
    
    override func draw(_ rect: CGRect) {
        
        guard let context = UIGraphicsGetCurrentContext() else { return }
        // get the drawing context and save the ground state
        context.saveGState()
        
        // add sky and grass, now they are just rectangles
        context.setFillColor(UIColor.cyan.cgColor)
        context.fill(sky(rect))
        
        context.setFillColor(UIColor.green.cgColor)
        context.fill(grass(rect))
        
        context.setFillColor(UIColor.brown.cgColor)
        
        context.addPath(gallowBase(rect))
        context.addPath(gallowHeight(rect))
        context.addPath(gallowAcross(rect))
        context.addPath(gallowTip(rect))
        
        context.fillPath()
        context.restoreGState()
        
    }
    
    
    
    func gallowBase(_ rect: CGRect) -> CGPath {
        
        let bottomLeftPoint = CGPoint(x: CGFloat(rect.width * DrawingConstants.gallowBaseStartScale), y: CGFloat(rect.height * DrawingConstants.grassHeightScale))
        let topLeftPoint = CGPoint(x: bottomLeftPoint.x, y: bottomLeftPoint.y - DrawingConstants.gallowBaseHeight)
        let topRightPoint = CGPoint(x: CGFloat(rect.width * DrawingConstants.gallowBaseEndScale), y: topLeftPoint.y)
        let bottomRightPoint = CGPoint(x: topRightPoint.x, y: bottomLeftPoint.y)
        
        let path = CGMutablePath()
        path.addLines(between: [bottomLeftPoint,topLeftPoint, topRightPoint,bottomRightPoint])
        path.closeSubpath()
        return path
    }
    
    func gallowHeight(_ rect: CGRect)  -> CGPath {
        let bottomLeftPoint = CGPoint(x: CGFloat(rect.width * DrawingConstants.gallowHeightStart), y: CGFloat(rect.height * DrawingConstants.grassHeightScale - DrawingConstants.gallowBaseHeight))
        let bottomRightPoint = CGPoint(x: bottomLeftPoint.x + DrawingConstants.gallowHeightWidth, y: bottomLeftPoint.y)
        let topLeftPoint = CGPoint(x: bottomLeftPoint.x, y: rect.height * DrawingConstants.gallowHeight)
        let topRightPoint = CGPoint(x: bottomRightPoint.x, y: topLeftPoint.y)
        
        let path = CGMutablePath()
        path.addLines(between: [bottomLeftPoint,topLeftPoint, topRightPoint,bottomRightPoint])
        path.closeSubpath()
        return path
    }
    
    func gallowAcross(_ rect: CGRect)  -> CGPath {
        let bottomLeftPoint = CGPoint(x: CGFloat(rect.width * DrawingConstants.gallowHeightStart) + DrawingConstants.gallowHeightWidth, y: CGFloat(rect.height * DrawingConstants.gallowHeight + DrawingConstants.gallowBaseHeight))
        
        
        let bottomRightPoint = CGPoint(x: CGFloat(rect.width * DrawingConstants.gallowAcrossScale), y: bottomLeftPoint.y)
        let topLeftPoint = CGPoint(x: bottomLeftPoint.x, y: CGFloat(rect.height * DrawingConstants.gallowHeight))
        let topRightPoint = CGPoint(x: CGFloat(bottomRightPoint.x), y: topLeftPoint.y)
        
        let path = CGMutablePath()
        path.addLines(between: [bottomLeftPoint,topLeftPoint, topRightPoint,bottomRightPoint])
        path.closeSubpath()
        return path
    }
    
    func gallowTip(_ rect: CGRect)  -> CGPath {
        let topLeftPoint = CGPoint(x: CGFloat(rect.width * DrawingConstants.gallowAcrossScale - DrawingConstants.gallowHeightWidth), y: CGFloat(rect.height * DrawingConstants.gallowHeight + DrawingConstants.gallowBaseHeight))
        let topRightPoint = CGPoint(x: CGFloat(rect.width * DrawingConstants.gallowAcrossScale), y: topLeftPoint.y)
        let bottomLeftPoint = CGPoint(x: topLeftPoint.x, y: topLeftPoint.y + DrawingConstants.gallowTipHeight)
        let bottomRightPoint = CGPoint(x: topRightPoint.x, y: bottomLeftPoint.y)
        
        let path = CGMutablePath()
        path.addLines(between: [bottomLeftPoint,topLeftPoint, topRightPoint,bottomRightPoint])
        path.closeSubpath()
        return path
    }
    
    
    
    func grass(_ rect: CGRect)  -> CGRect {
        let grassRect = CGRect(x: 0, y: rect.height * DrawingConstants.grassHeightScale, width: rect.width, height: (1 - DrawingConstants.grassHeightScale) * rect.height)
        return grassRect
    }
    
    func sky(_ rect: CGRect)  -> CGRect {
        
        let skyRect = CGRect(x: 0, y: 0, width: rect.width, height: DrawingConstants.grassHeightScale * rect.height)
        
        return skyRect
        
    }
    
    
    func calculateMidPoint(point1: CGPoint, point2: CGPoint) -> CGPoint {
        return CGPoint(x: (point1.x + point2.x) / 2, y: (point1.y + point2.y) / 2)
        
    }
    
    
    struct DrawingConstants {
        static let gallowBaseStartScale: CGFloat = 0.15
        static let gallowBaseEndScale: CGFloat = 0.85
        static let gallowBaseHeight: CGFloat = 10
        static let gallowHeight: CGFloat = 0.05        //static let gallowHeight: CGFloat = 0.15
        static let gallowHeightStart: CGFloat = 0.175
        static let gallowHeightWidth: CGFloat = 10
        static let gallowAcrossScale: CGFloat = 0.5
        static let gallowTipHeight: CGFloat = 17.5
        static let headRadius: CGFloat = 16
        static let bodyLength: CGFloat = 25
        static let bodyHeight: CGFloat = 25
        static let legLength: CGFloat = 50
        static let grassHeightScale: CGFloat = 0.68
        static let armBack: CGFloat = 5
    }
    
    struct ScaleConstants {
        static let bodyLength: CGFloat = 50
        static let limbLength: CGFloat = 25
        static let handHeightScale: CGFloat = 0.4
        static let headRadius: CGFloat = 20
        static let eyeRadius = 0.15 * headRadius
        static let eyeOffset = 0.3 * headRadius
        static let mouthOffSet = 0.3 * headRadius
        static let mouthRadius = 0.25 * headRadius
    }
}
