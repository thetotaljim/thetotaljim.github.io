//
//  GameModel.swift
//  HMan
//
//  Created by James Steimel on 11/29/16.
//  Copyright © 2016 James Steimel. All rights reserved.
//

import UIKit

enum DiffGuessNum : Int {
    case Easy = 9
    case Normal = 8
    case Hard = 6
    
}

protocol GameModelDelegate : class {
    func setWordLabel(word: NSString)
    func setGuessedLabel(word: NSString)
    func setAttributedString(text: NSMutableAttributedString)
    func gameOver()
    func addABodyPart(part: BodyPart)
    func getWordLabelText() -> NSString
}


class GameModel  {
    
    weak var delegate : GameModelDelegate?
    private var difficulty: UserDiff?
    //  Set to normal as default
    private var guessNumber = DiffGuessNum.Normal
    private var wantsToQuit: Bool = false
    private(set) var wordToGuess = NSString()
    private(set) var attempts = 0
    private var score = 0
    private var guessedArray = [NSString]()
    private var youWon : Bool = false
    private let DifficultyList = [
        "Easy",
        "Normal",
        "Hard",
    ]
    
    func getWinOrLose()->Bool{
        return youWon
    }

    init(diff: UserDiff){
        self.difficulty = diff
        setDiffGuessNum()
    }
    
    func setDiffGuessNum() {
        if ( difficulty == UserDiff.Easy){
            guessNumber = DiffGuessNum.Easy
        }
        else if ( difficulty == UserDiff.Hard){
            guessNumber = DiffGuessNum.Hard
        }
        else {
            guessNumber = DiffGuessNum.Normal
        }
    }
    
    /********************************************************************/
    /*                                                                  */
    /*   SET THE WORD THAT THE USER WILL TRY AND GUESS  getRandWord()   */
    /*                                                                  */
    /********************************************************************/
    
    func getRandomWord() {
        
        //  Gets the root of my plist of words
        let dictRoot = NSDictionary(contentsOfFile: Bundle.main.path(forResource: "MyPropertyList", ofType: "plist")!)
        //  Here an array is generated from the plist
        let wordsArr = dictRoot?.object(forKey: (difficulty?.rawValue)!) as! NSArray
        //  This is a random word taken from the previous array
        let randomWord = Int(arc4random() % UInt32(wordsArr.count))
        //  Set the wordToGuess NSString object.
        wordToGuess = "\(wordsArr[randomWord])" as NSString
        //  User the wordToGuess value to set the label that
        //  is used to display the word used for that game.
        setupWord((wordToGuess))
        //  Set the attempts in the model to 0 to start the game.
        attempts = 0
        
    }
    
    func getAttributedString(string: String) -> NSMutableAttributedString{
        let attributedString = NSMutableAttributedString(string: string)
        attributedString.addAttribute(NSKernAttributeName, value: CGFloat(1.9), range: NSRange(location: 0, length: string.characters.count))
        return attributedString
    }
    
    // MARK: - SETUP WORD
    func setupWord(_ word: NSString) {
        
        let myString = wordToGuess as String
        let fixed = myString.replacingOccurrences(of: "[A-Z]", with: "_", options: .regularExpression, range: myString.startIndex..<myString.endIndex)
        delegate?.setWordLabel(word: "")
        delegate?.setWordLabel(word:fixed as NSString)
        var attribStrng = NSMutableAttributedString()
        attribStrng = getAttributedString(string: fixed)
        delegate?.setAttributedString(text: attribStrng)
        
    }
    
    // MARK: - CHECK IF THE CHOOSE LETTER DOES EXIST
    func checkIfLetterExists(_ letterToCheck:NSString) {
        
        if guessedArray.contains(letterToCheck){
            return
        }
        else {
            guessedArray.append(letterToCheck)
        }
        // Flag for noting whether button character matches a character in the word string
        var match = false
        var letterRange = NSRange()
        let charToCheck = letterToCheck.character(at: 0)
        
        /********************************************************************/
        /* HERE WE CHECK TO SEE IF USERS SELECTED LETTER IS IN THE WORD     */
        /********************************************************************/
        let len = wordToGuess.length
        for i in 0..<Int(len) {
            let tempChar = wordToGuess.character(at: i)
            if charToCheck == tempChar {
                match = true
                letterRange = NSMakeRange(i, 1)
                let wordStr:NSString = (delegate?.getWordLabelText())!
                let tempString = wordStr.replacingCharacters(in: letterRange, with: String(letterToCheck))
                var attribStrng = NSMutableAttributedString()
                attribStrng = getAttributedString(string: tempString)
                delegate?.setAttributedString(text: attribStrng)
                
                /************************************************************/
                /*  HERE IS WHERE A WIN IS DETERMINED                       */
                /************************************************************/
                if delegate?.getWordLabelText() == (wordToGuess) {
                    delegate?.setGuessedLabel(word: "You've guessed the word!" as NSString)
                    youWon = true
                    delegate?.gameOver()
                }
            }
        }
        /********************************************************************/
        /*              IF THE LETTER DOES NOT EXIST                        */
        /********************************************************************/
        if !match {
            attempts += 1
            
            // GAME OVER!
            print("Guess Number Raw Value: ", guessNumber.rawValue)
            if (attempts) > (guessNumber.rawValue) { delegate?.gameOver() }
            delegate?.addABodyPart(part: BodyPart(rawValue: attempts)!)
            delegate?.setGuessedLabel(word: "You have \(guessNumber.rawValue-attempts+1) guesses left!" as NSString)
        }
    }
    
}
